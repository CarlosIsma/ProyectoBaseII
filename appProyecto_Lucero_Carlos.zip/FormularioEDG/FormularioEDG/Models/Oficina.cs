﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FormularioEDG.Model
{
    public class Oficina
    {
        [Key]
        public int id_oficina { get; set; }
        [Display(Name = "NOMBRE DE LA OFICINA")]
        public string nombre { get; set; }
        [Display(Name = "USO INEC")]
        public string uso_inec { get; set; }
        [Display(Name = "DIRECCIÓN DE LA OFICINA")]
        public int id_ubicacion { get; set; }
        [Display(Name = "DIRECCIÓN DE LA OFICINA")]
        public Ubicacion Ubicacion { get; set; }

        public ICollection<FormularioEdg> FormularioEdgs { get; set; }


    }
}