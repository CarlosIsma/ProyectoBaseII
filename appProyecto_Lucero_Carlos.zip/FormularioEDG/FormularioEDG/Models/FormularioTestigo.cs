﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FormularioEDG.Model
{
    public class FormularioTestigo
    {
        [Key]
        public int id_formulario_testigo { get; set; }
        [Display(Name = "CAUSA PROBABLE DE LA MUERTE")]
        public string causa { get; set; }
        [Display(Name = "SINTOMAS")]
        public string sintoma { get; set; }
        [Display(Name = "NOMBRE Y APELLIDO DEL TESTIGO")]
        public string nombre { get; set; }
        [Display(Name = "DIRECCIÓN DEL TESTIGO")]
        public string direccion { get; set; }
        [Display(Name = "TELÉFONO DEL TESTIGO")]
        public string telefono { get; set; }
        [Display(Name = "CÓDIGO FORMULARIO")]
        public int id_formulario { get; set; }
        [Display(Name = "CÓDIGO FORMULARIO")]
        public FormularioEdg FormularioEdg { get; set; }
    }
}