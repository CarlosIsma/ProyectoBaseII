﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FormularioEDG.Model
{
    public class FormularioEdg
    {
        [Key]
        public int id_formulario { get; set; }
        [Display(Name = "FOLIO")]
        public long numero_formulario { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString ="{0:dd/MM/yyyy}")]
        [Display(Name = "FECHA INEC CRITICA")]
        public DateTime fecha_inec { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "FECHA DE INSCRIPCIÓN")]
        public DateTime fecha_inscripcion { get; set; }
        [Display(Name = "ACTA DE INSCRIPCIÓN")]
        public string acta_inscripcion { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "FECHA DE FALLECIMIENTO")]
        public DateTime fecha_fallecimiento { get; set; }
        [Display(Name = "EDAD AL FALLECER")]
        public string edad { get; set; }
        [Display(Name = "MORTALIDAD MATERNA")]
        public string mortalidad_materna { get; set; }
        [Display(Name = "MUERTES ACCIDENTALES Y/O VIOLENTAS")]
        public string tipo_accidente { get; set; }
        [Display(Name = "LUGAR DONDE OCURRIO EL HECHO")]
        public string lugar_accidente { get; set; }
        [Display(Name = "DESCRIPCIÓN DEL ACCIDENTE")]
        public string descripcion_accidente { get; set; }
        [Display(Name = "SE REALIZÓ NECROPCIA / AUTOPCIA ?")]
        public bool autopsia { get; set; }
        [Display(Name = "CERTIFICADO POR: ")]
        public string inscrito_por { get; set; }
        [Display(Name = "NOMBRES Y APELLIDOS")]
        public string nombre_defuncion { get; set; }
        [Display(Name = "DIRECCIÓN DE CONSULTORIO O DOMICILIO")]
        public string direccion_defuncion { get; set; }
        [Display(Name = "TELÉFONO")]
        public string telefono_defuncion { get; set; }
        [Display(Name = "NOMRES Y APELLIDOS DE QUIEN SOLICITA LA INSCRIPCIÓN")]
        public string nombre_solicitante { get; set; }
        [Display(Name = "EDAD")]
        public int edad_solicitante { get; set; }
        [Display(Name = "RELACIÓN DE PARENTESCO CON EL FALLECIDO/A")]
        public string parentesco { get; set; }
        [Display(Name = "OBSERVACIONES")]
        public string observacion { get; set; }
        [Display(Name = "CODIFICADOR")]
        public int codigo_critico { get; set; }
        [Display(Name = "LUGAR DE OCURRENCIA DEL FALLECIMIENTO")]
        public string lugar_fallecimiento { get; set; }
        [Display(Name = "NOMBRE DEL LUGAR")]
        public string nombre_lugar { get; set; }
        [Display(Name = "DIRECCIÓN")]
        public string direccion_lugar { get; set; }
        [Display(Name = "TELÉFONO")]
        public string telefono_lugar { get; set; }
        [Display(Name = "USO INEC")]
        public string codigo_inec_lugar { get; set; }
        [Display(Name = "CÉDULA DE CIUDADANÍA O PASAPORTE")]
        public int id_persona { get; set; }
        [Display(Name = "CÉDULA DE CIUDADANÍA O PASAPORTE")]
        public Persona Persona { get; set; }
        [Display(Name = "OFICINA INEC")]
        public int id_oficina { get; set; }
        [Display(Name = "OFICINA INEC")]
        public Oficina Oficina { get; set; }
        [Display(Name = "LUGAR DONDE OCURRIO EL FALLECIMIENTO")]
        public int id_ubicacion { get; set; }
        [Display(Name = "LUGAR DONDE OCURRIO EL FALLECIMIENTO")]
        public Ubicacion Ubicacion { get; set; }

        public ICollection<FormularioTestigo> FormularioTestigos { get; set; }
        public ICollection<FormularioCertificado> FormularioCertificados { get; set; }
    }
}