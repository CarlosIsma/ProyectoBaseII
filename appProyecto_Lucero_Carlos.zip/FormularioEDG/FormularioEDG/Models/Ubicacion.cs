﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FormularioEDG.Model
{
    public class Ubicacion
    {
        [Key]
        public int id_ubicacion { get; set; }
        [Display(Name = "PROVINCIA")]
        public string provincia { get; set; }
        [Display(Name = "CANTÓN")]
        public string canton { get; set; }
        [Display(Name = "PARRÓQUIA")]
        public string parroquia { get; set; }
        [Display(Name = "LOACLIDAD")]
        public string localidad { get; set; }
        [Display(Name = "DPA INEC")]
        public string dpa_inec { get; set; }
        [Display(Name = "LOCALIDAD INEC")]
        public string localidad_inec { get; set; }

        public string nombre_completo
        {
            get
            {
                return provincia + " - " + canton + " - " + parroquia;
            }
        }

        public ICollection<FormularioEdg> FormularioEdgs { get; set; }


    }
}