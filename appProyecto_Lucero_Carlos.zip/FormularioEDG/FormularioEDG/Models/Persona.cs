﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FormularioEDG.Model
{

    public class Persona
    {
        [Key]

        public int id_persona { get; set; }
        [Required(ErrorMessage = "Campo Obligatorio")]
        [Display(Name = "CÉDULA DE CIUDADANÍA O PASAPORTE")]
        public string cedula { get; set; }
        [Required(ErrorMessage = "Campo Obligatorio")]
        [Display(Name = "NOMBRES Y APELLIDOS")]
        public string nombre { get; set; }
        [Required(ErrorMessage = "Campo Obligatorio")]
        [Display(Name = "NACIONALIDAD")]
        public string nacionalidad { get; set; }
        
        [Display(Name = "SEXO")]
        public string sexo { get; set; }
        
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "FECHA DE NACIMIENTO")]
        public DateTime fecha_nacimiento { get; set; }
        [Required(ErrorMessage = "Campo Obligatorio")]
        [Display(Name = "DIRECCIÓN DOMICILIARIA")]
        public string direccion { get; set; }
        
        [Display(Name = "ESTADO CIVIL y/o CONYUGAL")]
        public string estado_civil { get; set; }
        
        [Display(Name = "DE ACUERDO CON LA CULTURA Y COSTUMBRES," +
            " CÓMO SE AUTOIDENTIFICABA EL FALLECIDO (A) ?")]
        public string etnia { get; set; }
       
        [Display(Name = "¿SABÍA LEER Y ESCRIBIR?")]
        public bool leer_escribir { get; set; }
        
        [Display(Name = "NIVEL DE INSTRUCCIÓN ALCANZADO")]
        public string instruccion { get; set; }

       
        public int id_ubicacion { get; set; }
        [Display(Name = "RESIDENCIA HABITUAL DEL FALLECIDO (A)")]
        public Ubicacion Ubicacion { get; set; }

        public ICollection<FormularioEdg> FormularioEdgs { get; set; }


    }
}