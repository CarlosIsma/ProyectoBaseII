﻿using Microsoft.EntityFrameworkCore;

namespace FormularioEDG.Model
{
    public class FormularioEdgContext : DbContext
    {
        public FormularioEdgContext(DbContextOptions<FormularioEdgContext> options) : base(options)
        {
        }

        public DbSet<FormularioEdg> FormularioEdgs { get; set; }
        public DbSet<FormularioTestigo> FormularioTestigos { get; set; }
        public DbSet<FormularioCertificado> FormularioCertificados { get; set; }
        public DbSet<Persona> Personas { get; set; }
        public DbSet<Oficina> Oficinas { get; set; }
        public DbSet<Ubicacion> Ubicaciones { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FormularioEdg>().ToTable("formulario");
            modelBuilder.Entity<FormularioTestigo>().ToTable("formulario_testigo");
            modelBuilder.Entity<FormularioCertificado>().ToTable("formulario_certificado");
            modelBuilder.Entity<Persona>().ToTable("persona");
            modelBuilder.Entity<Oficina>().ToTable("oficina");
            modelBuilder.Entity<Ubicacion>().ToTable("ubicacion");

        }

    }
}
