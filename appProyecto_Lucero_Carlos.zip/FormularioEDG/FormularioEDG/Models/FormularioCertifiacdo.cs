﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FormularioEDG.Model
{
    public class FormularioCertificado
    {
        [Key]
        public int id_certificado_formulario { get; set; }
        [Display(Name = "CAUSA PROBABLE DE LA MUERTE")]
        public string causa { get; set; }
        [Display(Name = "TIEMPO APROXIMADO ENTRE EL COMIENZO DE CADA CAUSA Y LA MUERTE")]
        public string tiempo { get; set; }
        [Display(Name = "CÓDIGO CIE")]
        public string codigo_cie { get; set; }
        [Display(Name = "DEBIDO A / CONSECUENCIA DE")]
        public string tipo { get; set; }
        [Display(Name = "CÓDIGO CAUSA INEC")]
        public string codigo_causa_inec { get; set; }
        [Display(Name = "CÓDIGO FORMULARIO")]
        public int id_formulario { get; set; }
        [Display(Name = "CÓDIGO FORMULARIO")]
        public FormularioEdg FormularioEdg { get; set; }
    }
}