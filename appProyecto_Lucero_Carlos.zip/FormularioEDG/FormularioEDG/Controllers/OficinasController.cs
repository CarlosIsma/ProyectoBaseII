﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FormularioEDG.Model;
using Microsoft.AspNetCore.Authorization;

namespace FormularioEDG.Controllers
{
    public class OficinasController : Controller
    {
        private readonly FormularioEdgContext _context;

        public OficinasController(FormularioEdgContext context)
        {
            _context = context;
        }

        // GET: Oficinas
        [Authorize]
        public async Task<IActionResult> Index()
        {
            var formularioEdgContext = _context.Oficinas.Include(o => o.Ubicacion);
            return View(await formularioEdgContext.ToListAsync());
        }

        // GET: Oficinas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oficina = await _context.Oficinas
                .Include(o => o.Ubicacion)
                .FirstOrDefaultAsync(m => m.id_oficina == id);
            if (oficina == null)
            {
                return NotFound();
            }

            return View(oficina);
        }

        // GET: Oficinas/Create
        public IActionResult Create()
        {
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "nombre_completo");
            return View();
        }

        // POST: Oficinas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id_oficina,nombre,uso_inec,id_ubicacion")] Oficina oficina)
        {
            if (ModelState.IsValid)
            {
                _context.Add(oficina);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "id_ubicacion", oficina.id_ubicacion);
            return View(oficina);
        }

        // GET: Oficinas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oficina = await _context.Oficinas.FindAsync(id);
            if (oficina == null)
            {
                return NotFound();
            }
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "id_ubicacion", oficina.id_ubicacion);
            return View(oficina);
        }

        // POST: Oficinas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id_oficina,nombre,uso_inec,id_ubicacion")] Oficina oficina)
        {
            if (id != oficina.id_oficina)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(oficina);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OficinaExists(oficina.id_oficina))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "id_ubicacion", oficina.id_ubicacion);
            return View(oficina);
        }

        // GET: Oficinas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oficina = await _context.Oficinas
                .Include(o => o.Ubicacion)
                .FirstOrDefaultAsync(m => m.id_oficina == id);
            if (oficina == null)
            {
                return NotFound();
            }

            return View(oficina);
        }

        // POST: Oficinas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oficina = await _context.Oficinas.FindAsync(id);
            _context.Oficinas.Remove(oficina);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OficinaExists(int id)
        {
            return _context.Oficinas.Any(e => e.id_oficina == id);
        }
    }
}
