﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FormularioEDG.Model;
using Microsoft.AspNetCore.Authorization;

namespace FormularioEDG.Controllers
{
    public class PersonasController : Controller
    {
        private readonly FormularioEdgContext _context;

        public PersonasController(FormularioEdgContext context)
        {
            _context = context;
        }

        // GET: Personas
        [Authorize]
        public async Task<IActionResult> Index()
        {
            var formularioEdgContext = _context.Personas.Include(p => p.Ubicacion);
            return View(await formularioEdgContext.ToListAsync());
        }

        // GET: Personas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var persona = await _context.Personas
                .Include(p => p.Ubicacion)
                .FirstOrDefaultAsync(m => m.id_persona == id);
            if (persona == null)
            {
                return NotFound();
            }

            return View(persona);
        }

        // GET: Personas/Create
        //[Authorize(User = "carlos.lucero@epn.edu.ec")]
        public IActionResult Create()
        {
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "nombre_completo");
            return View();
        }

        // POST: Personas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id_persona,cedula,nombre,nacionalidad,sexo,fecha_nacimiento,direccion,estado_civil,etnia,leer_escribir,instruccion,id_ubicacion")] Persona persona)
        {
            if (ModelState.IsValid)
            {
                _context.Add(persona);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "id_ubicacion", persona.id_ubicacion);
            return View(persona);
        }

        // GET: Personas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var persona = await _context.Personas.FindAsync(id);
            if (persona == null)
            {
                return NotFound();
            }
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "id_ubicacion", persona.id_ubicacion);
            return View(persona);
        }

        // POST: Personas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id_persona,cedula,nombre,nacionalidad,sexo,fecha_nacimiento,direccion,estado_civil,etnia,leer_escribir,instruccion,id_ubicacion")] Persona persona)
        {
            if (id != persona.id_persona)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(persona);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PersonaExists(persona.id_persona))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "id_ubicacion", persona.id_ubicacion);
            return View(persona);
        }

        // GET: Personas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var persona = await _context.Personas
                .Include(p => p.Ubicacion)
                .FirstOrDefaultAsync(m => m.id_persona == id);
            if (persona == null)
            {
                return NotFound();
            }

            return View(persona);
        }

        // POST: Personas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var persona = await _context.Personas.FindAsync(id);
            _context.Personas.Remove(persona);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PersonaExists(int id)
        {
            return _context.Personas.Any(e => e.id_persona == id);
        }
    }
}
