﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FormularioEDG.Model;
using Microsoft.AspNetCore.Authorization;

namespace FormularioEDG.Controllers
{
    public class FormularioCertificadosController : Controller
    {
        private readonly FormularioEdgContext _context;

        public FormularioCertificadosController(FormularioEdgContext context)
        {
            _context = context;
        }

        // GET: FormularioCertificados
        [Authorize]
        public async Task<IActionResult> Index(int? id)
        {
            var formularioEdgContext = _context.FormularioCertificados.Include(f => f.FormularioEdg);

            var busqueda = from s in formularioEdgContext select s;

            busqueda = busqueda.Where(s => s.id_formulario.Equals(id));

            //return View(await formularioEdgContext.ToListAsync());

            ViewData["idFormulario"] = id;
            return View(await busqueda.ToListAsync());
        }

        // GET: FormularioCertificados/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioCertificado = await _context.FormularioCertificados
                .Include(f => f.FormularioEdg)
                .FirstOrDefaultAsync(m => m.id_certificado_formulario == id);
            if (formularioCertificado == null)
            {
                return NotFound();
            }

            return View(formularioCertificado);
        }

        // GET: FormularioCertificados/Create
        public IActionResult Create(int? id)
        {
            //ViewData["id_formulario"] = new SelectList(_context.FormularioEdgs, "id_formulario", "id_formulario");
            ViewData["idFormulario"] = id;
            return View();
        }

        // POST: FormularioCertificados/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id_certificado_formulario,causa,tiempo,codigo_cie,tipo,codigo_causa_inec,id_formulario")] FormularioCertificado formularioCertificado)
        {
            if (ModelState.IsValid)
            {
                _context.Add(formularioCertificado);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index/" + formularioCertificado.id_formulario);
            }
            ViewData["id_formulario"] = new SelectList(_context.FormularioEdgs, "id_formulario", "id_formulario", formularioCertificado.id_formulario);
            return View(formularioCertificado);
        }

        // GET: FormularioCertificados/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioCertificado = await _context.FormularioCertificados.FindAsync(id);
            if (formularioCertificado == null)
            {
                return NotFound();
            }
            ViewData["id_formulario"] = new SelectList(_context.FormularioEdgs, "id_formulario", "id_formulario", formularioCertificado.id_formulario);
            return View(formularioCertificado);
        }

        // POST: FormularioCertificados/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id_certificado_formulario,causa,tiempo,codigo_cie,tipo,codigo_causa_inec,id_formulario")] FormularioCertificado formularioCertificado)
        {
            if (id != formularioCertificado.id_certificado_formulario)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(formularioCertificado);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FormularioCertificadoExists(formularioCertificado.id_certificado_formulario))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["id_formulario"] = new SelectList(_context.FormularioEdgs, "id_formulario", "id_formulario", formularioCertificado.id_formulario);
            return View(formularioCertificado);
        }

        // GET: FormularioCertificados/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioCertificado = await _context.FormularioCertificados
                .Include(f => f.FormularioEdg)
                .FirstOrDefaultAsync(m => m.id_certificado_formulario == id);
            if (formularioCertificado == null)
            {
                return NotFound();
            }

            return View(formularioCertificado);
        }

        // POST: FormularioCertificados/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var formularioCertificado = await _context.FormularioCertificados.FindAsync(id);
            _context.FormularioCertificados.Remove(formularioCertificado);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FormularioCertificadoExists(int id)
        {
            return _context.FormularioCertificados.Any(e => e.id_certificado_formulario == id);
        }
    }
}
