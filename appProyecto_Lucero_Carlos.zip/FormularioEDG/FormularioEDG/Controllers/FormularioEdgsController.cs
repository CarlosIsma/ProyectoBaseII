﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FormularioEDG.Model;
using Microsoft.AspNetCore.Authorization;

namespace FormularioEDG.Controllers
{
    public class FormularioEdgsController : Controller
    {
        private readonly FormularioEdgContext _context;

        public FormularioEdgsController(FormularioEdgContext context)
        {
            _context = context;
        }

        // GET: FormularioEdgs
         [Authorize]
        public async Task<IActionResult> Index()
        {
            var formularioEdgContext = _context.FormularioEdgs.Include(f => f.Oficina).Include(f => f.Persona).Include(f => f.Ubicacion);
            return View(await formularioEdgContext.ToListAsync());
        }

        // GET: FormularioEdgs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioEdg = await _context.FormularioEdgs
                .Include(f => f.Oficina)
                .Include(f => f.Persona)
                .Include(f => f.Ubicacion)
                .FirstOrDefaultAsync(m => m.id_formulario == id);
            if (formularioEdg == null)
            {
                return NotFound();
            }

            return View(formularioEdg);
        }

        // GET: FormularioEdgs/Create
        //[Authorize(Users = "carlos.lucero@epn.edu.ec")]
        public IActionResult Create()
        {
            ViewData["id_oficina"] = new SelectList(_context.Oficinas, "id_oficina", "nombre");
            ViewData["id_persona"] = new SelectList(_context.Personas, "id_persona", "cedula");
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "nombre_completo");
            return View();
        }

        // POST: FormularioEdgs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id_formulario,numero_formulario,fecha_inec,fecha_inscripcion,acta_inscripcion,fecha_fallecimiento,edad,mortalidad_materna,tipo_accidente,lugar_accidente,descripcion_accidente,autopsia,inscrito_por,nombre_defuncion,direccion_defuncion,telefono_defuncion,nombre_solicitante,edad_solicitante,parentesco,observacion,codigo_critico,lugar_fallecimiento,nombre_lugar,direccion_lugar,telefono_lugar,codigo_inec_lugar,id_persona,id_oficina,id_ubicacion")] FormularioEdg formularioEdg)
        {
            if (ModelState.IsValid)
            {
                _context.Add(formularioEdg);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["id_oficina"] = new SelectList(_context.Oficinas, "id_oficina", "id_oficina", formularioEdg.id_oficina);
            ViewData["id_persona"] = new SelectList(_context.Personas, "id_persona", "id_persona", formularioEdg.id_persona);
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "id_ubicacion", formularioEdg.id_ubicacion);
            return View(formularioEdg);
        }

        // GET: FormularioEdgs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioEdg = await _context.FormularioEdgs.FindAsync(id);
            if (formularioEdg == null)
            {
                return NotFound();
            }
            ViewData["id_oficina"] = new SelectList(_context.Oficinas, "id_oficina", "id_oficina", formularioEdg.id_oficina);
            ViewData["id_persona"] = new SelectList(_context.Personas, "id_persona", "id_persona", formularioEdg.id_persona);
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "nombre_completo", formularioEdg.id_ubicacion);
            return View(formularioEdg);
        }

        // POST: FormularioEdgs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id_formulario,numero_formulario,fecha_inec,fecha_inscripcion,acta_inscripcion,fecha_fallecimiento,edad,mortalidad_materna,tipo_accidente,lugar_accidente,descripcion_accidente,autopsia,inscrito_por,nombre_defuncion,direccion_defuncion,telefono_defuncion,nombre_solicitante,edad_solicitante,parentesco,observacion,codigo_critico,lugar_fallecimiento,nombre_lugar,direccion_lugar,telefono_lugar,codigo_inec_lugar,id_persona,id_oficina,id_ubicacion")] FormularioEdg formularioEdg)
        {
            if (id != formularioEdg.id_formulario)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(formularioEdg);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FormularioEdgExists(formularioEdg.id_formulario))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["id_oficina"] = new SelectList(_context.Oficinas, "id_oficina", "id_oficina", formularioEdg.id_oficina);
            ViewData["id_persona"] = new SelectList(_context.Personas, "id_persona", "id_persona", formularioEdg.id_persona);
            ViewData["id_ubicacion"] = new SelectList(_context.Ubicaciones, "id_ubicacion", "id_ubicacion", formularioEdg.id_ubicacion);
            return View(formularioEdg);
        }

        // GET: FormularioEdgs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioEdg = await _context.FormularioEdgs
                .Include(f => f.Oficina)
                .Include(f => f.Persona)
                .Include(f => f.Ubicacion)
                .FirstOrDefaultAsync(m => m.id_formulario == id);
            if (formularioEdg == null)
            {
                return NotFound();
            }

            return View(formularioEdg);
        }

        // POST: FormularioEdgs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var formularioEdg = await _context.FormularioEdgs.FindAsync(id);
            _context.FormularioEdgs.Remove(formularioEdg);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FormularioEdgExists(int id)
        {
            return _context.FormularioEdgs.Any(e => e.id_formulario == id);
        }
    }
}
