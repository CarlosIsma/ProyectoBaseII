﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FormularioEDG.Model;
using Microsoft.AspNetCore.Authorization;

namespace FormularioEDG.Controllers
{
    public class FormularioTestigosController : Controller
    {
        private readonly FormularioEdgContext _context;

        public FormularioTestigosController(FormularioEdgContext context)
        {
            _context = context;
        }

        // GET: FormularioTestigos
        [Authorize]
        public async Task<IActionResult> Index(int? id)
        {
            var formularioEdgContext = _context.FormularioTestigos.Include(f => f.FormularioEdg);

            var busqueda = from s in formularioEdgContext select s;

            busqueda = busqueda.Where(s => s.id_formulario.Equals(id));

            //return View(await formularioEdgContext.ToListAsync());
            ViewData["idFormulario"] = id;
            return View(await busqueda.ToListAsync());
        }

        // GET: FormularioTestigos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioTestigo = await _context.FormularioTestigos
                .Include(f => f.FormularioEdg)
                .FirstOrDefaultAsync(m => m.id_formulario_testigo == id);
            if (formularioTestigo == null)
            {
                return NotFound();
            }

            return View(formularioTestigo);
        }

        // GET: FormularioTestigos/Create
        public IActionResult Create(int? id)
        {
            //ViewData["id_formulario"] = new SelectList(_context.FormularioEdgs, "id_formulario", "id_formulario", id);
            ViewData["idFormulario"] = id;
            return View();
        }

        // POST: FormularioTestigos/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id_formulario_testigo,causa,sintoma,nombre,direccion,telefono,id_formulario")] FormularioTestigo formularioTestigo)
        {
            if (ModelState.IsValid)
            {
                _context.Add(formularioTestigo);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index/"+ formularioTestigo.id_formulario);
            }
            ViewData["id_formulario"] = new SelectList(_context.FormularioEdgs, "id_formulario", "id_formulario", formularioTestigo.id_formulario);
            return View(formularioTestigo);
        }

        // GET: FormularioTestigos/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioTestigo = await _context.FormularioTestigos.FindAsync(id);
            if (formularioTestigo == null)
            {
                return NotFound();
            }
            ViewData["id_formulario"] = new SelectList(_context.FormularioEdgs, "id_formulario", "id_formulario", formularioTestigo.id_formulario);
            return View(formularioTestigo);
        }

        // POST: FormularioTestigos/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id_formulario_testigo,causa,sintoma,nombre,direccion,telefono,id_formulario")] FormularioTestigo formularioTestigo)
        {
            if (id != formularioTestigo.id_formulario_testigo)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(formularioTestigo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FormularioTestigoExists(formularioTestigo.id_formulario_testigo))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["id_formulario"] = new SelectList(_context.FormularioEdgs, "id_formulario", "id_formulario", formularioTestigo.id_formulario);
            return View(formularioTestigo);
        }

        // GET: FormularioTestigos/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var formularioTestigo = await _context.FormularioTestigos
                .Include(f => f.FormularioEdg)
                .FirstOrDefaultAsync(m => m.id_formulario_testigo == id);
            if (formularioTestigo == null)
            {
                return NotFound();
            }

            return View(formularioTestigo);
        }

        // POST: FormularioTestigos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var formularioTestigo = await _context.FormularioTestigos.FindAsync(id);
            _context.FormularioTestigos.Remove(formularioTestigo);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FormularioTestigoExists(int id)
        {
            return _context.FormularioTestigos.Any(e => e.id_formulario_testigo == id);
        }
    }
}
